package com.officepad.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var currentUri: Uri? = null
    private var pendingBytes: ByteArray? = null
    private val io = Executors.newSingleThreadExecutor()

    private val openLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != RESULT_OK) { jsResult(false, "Pembukaan file dibatalkan."); return@registerForActivityResult }
        val uri = result.data?.data ?: return@registerForActivityResult
        currentUri = uri
        try {
            val flags = result.data?.flags ?: 0
            val take = flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            if (take != 0) contentResolver.takePersistableUriPermission(uri, take)
        } catch (_: Exception) { }
        io.execute {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("File tidak dapat dibaca")
                val name = try { contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) ?: "Dokumen" else "Dokumen" } ?: "Dokumen" } catch (_: Exception) { "Dokumen" }
                val mime = contentResolver.getType(uri) ?: "application/octet-stream"
                val b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                runOnUiThread { web.evaluateJavascript("window.OfficePad.onFileOpened(${JSONObject.quote(name)},${JSONObject.quote(mime)},${JSONObject.quote(b64)});", null) }
            } catch (e: Exception) { jsResult(false, "Gagal membuka file: ${e.message ?: "kesalahan"}") }
        }
    }

    private val saveLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = result.data?.data
        val bytes = pendingBytes
        pendingBytes = null
        if (result.resultCode != RESULT_OK || uri == null || bytes == null) { jsResult(false, "Save As dibatalkan."); return@registerForActivityResult }
        io.execute {
            try {
                contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) } ?: throw IOException("Lokasi tidak dapat ditulis")
                currentUri = uri
                runOnUiThread { web.evaluateJavascript("window.OfficePad.onSaveResult(true,'File berhasil disimpan.');", null) }
            } catch (e: Exception) { jsResult(false, "Gagal menyimpan: ${e.message ?: "kesalahan"}") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private inner class Bridge {
        @JavascriptInterface fun openDocument() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                openLauncher.launch(i)
            }
        }
        @JavascriptInterface fun saveCurrent(name: String, mime: String, base64: String) {
            val bytes = decode(base64) ?: run { jsResult(false, "Data dokumen tidak valid"); return }
            val uri = currentUri
            if (uri == null) { saveAs(name, mime, base64); return }
            io.execute {
                try {
                    contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) } ?: throw IOException("File tidak mendukung penulisan")
                    runOnUiThread { web.evaluateJavascript("window.OfficePad.onSaveResult(true,'Perubahan tersimpan ke file yang dibuka.');", null) }
                } catch (e: Exception) {
                    runOnUiThread { web.evaluateJavascript("window.OfficePad.onSaveResult(false,${JSONObject.quote("Tidak dapat menimpa file asli. Gunakan Save As. ${e.message ?: ""}")});", null) }
                }
            }
        }
        @JavascriptInterface fun saveAs(name: String, mime: String, base64: String) {
            pendingBytes = decode(base64) ?: run { jsResult(false, "Data dokumen tidak valid"); return }
            runOnUiThread {
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = mime; putExtra(Intent.EXTRA_TITLE, name) }
                saveLauncher.launch(i)
            }
        }
    }
    private fun decode(s: String): ByteArray? = try { android.util.Base64.decode(s, android.util.Base64.DEFAULT) } catch (_: Exception) { null }
    private fun jsResult(ok: Boolean, message: String) { runOnUiThread { if (::web.isInitialized) web.evaluateJavascript("window.OfficePad && window.OfficePad.onSaveResult($ok,${JSONObject.quote(message)});", null) } }
    override fun onDestroy() { if (::web.isInitialized) { web.removeJavascriptInterface("AndroidBridge"); web.destroy() }; io.shutdown(); super.onDestroy() }
}
