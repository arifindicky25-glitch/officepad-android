# OfficePad Desktop for Android — MVP 0.2

OfficePad is an early Android prototype with a desktop-inspired workspace.

## Included
- Native Android shell with Android Storage Access Framework file picker.
- Writer: rich-text editing, basic DOCX text import/export, and HTML export. DOCX round-tripping preserves basic paragraphs and text only; advanced formatting, tables, images, and layout may be lost.
- Spreadsheet: editable grid, basic arithmetic, SUM/AVERAGE/MIN/MAX and CSV import/export.
- Slides: simple slide editor and OfficePad JSON export.
- Save attempts to overwrite the selected document URI. If the provider denies writing, use Save As.
- GitHub Actions workflow to build a debug APK in the cloud.

## Important limitation
This is **not yet equivalent to WPS Office PC**. DOCX support is limited to basic paragraph text. XLSX, PPTX, and PDF are not supported yet. Spreadsheet exports CSV, and Slides exports an OfficePad-specific JSON format. Keep a backup of important files. Full Office compatibility requires a mature document engine and substantial testing.

## Build APK with GitHub Actions
1. Create a new GitHub repository.
2. Upload the **contents** of this folder to the repository root (not the ZIP itself).
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build OfficePad APK** using **Run workflow**, or push a commit to `main`.
5. Open the successful workflow run, scroll to **Artifacts**, and download `officepad-debug-apk`.
6. Extract that artifact ZIP on Android and install `app-debug.apk`. Allow installation from the browser/file manager if Android asks.

## Privacy
The app declares no network permission and uses Android's system document picker. File data is handled locally.
