package com.officepad.app

import android.content.Intent
import android.text.Html
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject
import java.io.IOException
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.xml.parsers.DocumentBuilderFactory
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var currentUri: Uri? = null
    private var currentFormatDocx = false
    private var pendingIsDocx = false
    private var pendingBytes: ByteArray? = null
    private val io = Executors.newSingleThreadExecutor()

    private val openLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != RESULT_OK) { jsResult(false, "Pembukaan file dibatalkan."); return@registerForActivityResult }
        val uri = result.data?.data ?: return@registerForActivityResult
        currentUri = uri
        try {
            val flags = result.data?.flags ?: 0
            val take = flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            if (take != 0) contentResolver.takePersistableUriPermission(uri, take)
        } catch (_: Exception) { }
        io.execute {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("File tidak dapat dibaca")
                val name = try { contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) ?: "Dokumen" else "Dokumen" } ?: "Dokumen" } catch (_: Exception) { "Dokumen" }
                val mime = contentResolver.getType(uri) ?: "application/octet-stream"
                val ext = name.substringAfterLast('.', "").lowercase()
                currentFormatDocx = ext == "docx"
                val (outputMime, outputBytes) = if (ext == "docx") {
                    "text/html" to docxToHtml(bytes).toByteArray(Charsets.UTF_8)
                } else {
                    mime to bytes
                }
                val b64 = android.util.Base64.encodeToString(outputBytes, android.util.Base64.NO_WRAP)
                runOnUiThread { web.evaluateJavascript("window.OfficePad.onFileOpened(${JSONObject.quote(name)},${JSONObject.quote(outputMime)},${JSONObject.quote(b64)});", null) }
            } catch (e: Exception) { jsResult(false, "Gagal membuka file: ${e.message ?: "kesalahan"}") }
        }
    }

    private val saveLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = result.data?.data
        val bytes = pendingBytes
        val isDocx = pendingIsDocx
        pendingBytes = null
        pendingIsDocx = false
        if (result.resultCode != RESULT_OK || uri == null || bytes == null) { jsResult(false, "Save As dibatalkan."); return@registerForActivityResult }
        io.execute {
            try {
                contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) } ?: throw IOException("Lokasi tidak dapat ditulis")
                currentUri = uri
                currentFormatDocx = isDocx
                runOnUiThread { web.evaluateJavascript("window.OfficePad.onSaveResult(true,'File berhasil disimpan.');", null) }
            } catch (e: Exception) { jsResult(false, "Gagal menyimpan: ${e.message ?: "kesalahan"}") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private inner class Bridge {
        @JavascriptInterface fun openDocument() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                openLauncher.launch(i)
            }
        }
        @JavascriptInterface fun saveCurrent(name: String, mime: String, base64: String) {
            val bytes = decode(base64) ?: run { jsResult(false, "Data dokumen tidak valid"); return }
            val uri = currentUri
            if (uri == null) { saveAs(name, mime, base64); return }
            io.execute {
                try {
                    val outputBytes = if (currentFormatDocx) htmlToDocx(String(bytes, Charsets.UTF_8)) else bytes
                    contentResolver.openOutputStream(uri, "wt")?.use { it.write(outputBytes) } ?: throw IOException("File tidak mendukung penulisan")
                    runOnUiThread { web.evaluateJavascript("window.OfficePad.onSaveResult(true,'Perubahan tersimpan ke file yang dibuka.');", null) }
                } catch (e: Exception) {
                    runOnUiThread { web.evaluateJavascript("window.OfficePad.onSaveResult(false,${JSONObject.quote("Tidak dapat menimpa file asli. Gunakan Save As. ${e.message ?: ""}")});", null) }
                }
            }
        }
        @JavascriptInterface fun saveAs(name: String, mime: String, base64: String) {
            val decoded = decode(base64) ?: run { jsResult(false, "Data dokumen tidak valid"); return }
            pendingIsDocx = name.endsWith(".docx", ignoreCase = true)
            pendingBytes = if (pendingIsDocx) htmlToDocx(String(decoded, Charsets.UTF_8)) else decoded
            runOnUiThread {
                val targetMime = if (name.endsWith(".docx", ignoreCase = true)) "application/vnd.openxmlformats-officedocument.wordprocessingml.document" else mime
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = targetMime; putExtra(Intent.EXTRA_TITLE, name) }
                saveLauncher.launch(i)
            }
        }
    }
    private fun docxToHtml(bytes: ByteArray): String {
        val entries = mutableMapOf<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && entry.name == "word/document.xml") {
                    val out = ByteArrayOutputStream()
                    zis.copyTo(out)
                    entries[entry.name] = out.toByteArray()
                    break
                }
                entry = zis.nextEntry
            }
        }
        val xml = entries["word/document.xml"] ?: throw IOException("File DOCX tidak memiliki word/document.xml")
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = true
            try { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) } catch (_: Exception) { }
            try { setFeature("http://xml.org/sax/features/external-general-entities", false) } catch (_: Exception) { }
            try { setFeature("http://xml.org/sax/features/external-parameter-entities", false) } catch (_: Exception) { }
        }
        val doc = factory.newDocumentBuilder().parse(ByteArrayInputStream(xml))
        val ns = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
        val paragraphs = doc.getElementsByTagNameNS(ns, "p")
        val html = StringBuilder("<!doctype html><html><head><meta charset=\"utf-8\"></head><body>")
        for (i in 0 until paragraphs.length) {
            val paragraph = paragraphs.item(i)
            val texts = (paragraph as org.w3c.dom.Element).getElementsByTagNameNS(ns, "t")
            val line = StringBuilder()
            for (j in 0 until texts.length) line.append(texts.item(j).textContent ?: "")
            html.append("<p>").append(escapeHtmlNative(line.toString())).append("</p>")
        }
        html.append("</body></html>")
        return html.toString()
    }

    private fun htmlToDocx(html: String): ByteArray {
        val plain = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString()
            .replace("\r\n", "\n").replace('\r', '\n').trimEnd()
        val lines = if (plain.isEmpty()) listOf("") else plain.split('\n')
        val paragraphs = lines.joinToString("") { line ->
            if (line.isEmpty()) "<w:p/>" else "<w:p><w:r><w:t xml:space=\"preserve\">${escapeXml(line)}</w:t></w:r></w:p>"
        }
        val documentXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>$paragraphs<w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="720" w:footer="720" w:gutter="0"/></w:sectPr></w:body></w:document>"""
        val contentTypes = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>"""
        val rootRels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>"""
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            fun add(name: String, data: String) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(data.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
            add("[Content_Types].xml", contentTypes)
            add("_rels/.rels", rootRels)
            add("word/document.xml", documentXml)
        }
        return out.toByteArray()
    }

    private fun escapeHtmlNative(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    private fun escapeXml(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")

    private fun decode(s: String): ByteArray? = try { android.util.Base64.decode(s, android.util.Base64.DEFAULT) } catch (_: Exception) { null }
    private fun jsResult(ok: Boolean, message: String) { runOnUiThread { if (::web.isInitialized) web.evaluateJavascript("window.OfficePad && window.OfficePad.onSaveResult($ok,${JSONObject.quote(message)});", null) } }
    override fun onDestroy() { if (::web.isInitialized) { web.removeJavascriptInterface("AndroidBridge"); web.destroy() }; io.shutdown(); super.onDestroy() }
}
